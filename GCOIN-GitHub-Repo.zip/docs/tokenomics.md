# GCOIN Tokenomics
Supply: Mintable.
