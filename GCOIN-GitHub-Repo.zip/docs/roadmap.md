# GCOIN Roadmap
- CoinGecko Listing
- CMC Listing
